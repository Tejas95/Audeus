#pragma once


#define PA_SAMPLE_TYPE		(paFloat32)
#define NUM_CHANNELS		(1)
#define SAMPLE_RATE			(44100)
#define FRAMES_PER_BUFFER   (64)
#define BLOCK_SIZE			int(0.400 * SAMPLE_RATE)